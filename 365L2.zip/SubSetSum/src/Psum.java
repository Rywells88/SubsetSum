
public class Psum {
	
	
private int P1;
private int P2;
private int I1;
private int I2;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public Psum(int p1, int p2, int indx1, int indx2)
	{
		P1 = p1;
		P2 = p2;
		I1 = indx1;
		I2 = indx2;
	}
	
	public Psum() {
		// TODO Auto-generated constructor stub
	}

	public int getP1()
	{
		return P1;
	}
	public int getP2()
	{
		return P2;
	}
	public void setP1(int p1)
	{
		P1 = p1;
	}
	public void setP2(int p2)
	{
		P2 = p2;
	}
	public void setIndex1(int indx1)
	{
		I1 = indx1;
	}
	public int getIndex1()
	{
		return I1;
	}
	public void setIndex2(int indx2)
	{
		I2 = indx2;
	}
	public int getIndex2()
	{
		return I2;
	}

}
